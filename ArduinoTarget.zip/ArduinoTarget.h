#pragma once

#include "IArduinoTarget.h"

struct $itemname$ : public IArduinoTarget<$itemname$> {
    static void setup(void) {

    }

    static void loop(void) {

    }
};