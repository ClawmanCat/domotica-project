#pragma once

#include "IArduinoTarget.h"

struct $itemname$ : public IArduinoTarget<$itemname$> {
    void setup(void) {

    }

    void loop(void) {

    }
};